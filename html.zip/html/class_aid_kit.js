var class_aid_kit =
[
    [ "healthToGain", "class_aid_kit.html#abcbcb43c5f3f41db9bb02aeb43c97bfa", null ],
    [ "wasAlreadyCollected", "class_aid_kit.html#a64c38dbdd5556278bcd4d173768e2027", null ]
];