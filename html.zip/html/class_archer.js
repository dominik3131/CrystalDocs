var class_archer =
[
    [ "Awake", "class_archer.html#a042a92dff70e5f91a11d3d84d803254b", null ],
    [ "check", "class_archer.html#a3677f24d33aa8c1e30fedf9cd249acc9", null ],
    [ "Update", "class_archer.html#a4a0b78979667266440c6900758aecfab", null ],
    [ "bowShooting", "class_archer.html#af165bfdeb9d62f5e62e05114d992d76b", null ],
    [ "playerInfo", "class_archer.html#af89aaee479048e8e39b050d63886055b", null ],
    [ "throwHook", "class_archer.html#a01519a1f76ce1a1b6d97801d9a88c565", null ]
];