var class_arrow =
[
    [ "OnTriggerEnter2D", "class_arrow.html#ad9f1607469e9da30c32e1fb402b645f7", null ],
    [ "Start", "class_arrow.html#a65ce0e1a14405dec237e13ee5631b07d", null ],
    [ "damage", "class_arrow.html#a37acc46f8d793cc86cef148645652c73", null ],
    [ "destroyDelay", "class_arrow.html#af3eba38cb6eedf4c12d63702815c7a72", null ],
    [ "rb", "class_arrow.html#a0686eae999c8de30e8f61a6746e32a8a", null ],
    [ "speed", "class_arrow.html#a606176bcd4e8cb46ed6c427266f87edf", null ]
];