var class_camera_fallow =
[
    [ "Awake", "class_camera_fallow.html#a6730167137f702e7ebbac6864d1c9266", null ],
    [ "FixedUpdate", "class_camera_fallow.html#a395318473aac63b39553404c1aca710c", null ],
    [ "cameraDistance", "class_camera_fallow.html#a142e0392f35c9e3147164c79e2606d86", null ],
    [ "player", "class_camera_fallow.html#af497b2082a0bd0fb8ecb436962ea634b", null ]
];