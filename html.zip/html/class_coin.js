var class_coin =
[
    [ "OnCollisionEnter2D", "class_coin.html#ac0f4183b024c7e12b74fa86cfd88facc", null ],
    [ "Start", "class_coin.html#a2b8eb271460dadfa9b2afec35a812a70", null ],
    [ "itemName", "class_coin.html#a53c16c257492f1957c0dab99aa60df65", null ],
    [ "playerInfo", "class_coin.html#a7b202468486340605d50f38eb3f44228", null ],
    [ "wasAlreadyCollected", "class_coin.html#a1fe152f96d4da1d8691e136dcb4cac5b", null ]
];