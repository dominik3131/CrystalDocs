var class_collsion_detect =
[
    [ "isFighting", "class_collsion_detect.html#abce3197a8380fa26a873dc582ea3ef84", null ],
    [ "pushForce", "class_collsion_detect.html#a5aac6397fd825b003f144f1353123ddf", null ]
];