var class_end_level =
[
    [ "ShowEndLevelScreen", "class_end_level.html#ae8f045e7af27936c16a489731e0e9b46", null ],
    [ "backToMenuButton", "class_end_level.html#a544a5feaa48949604b0e32e2a52a16ad", null ],
    [ "CoinAmountText", "class_end_level.html#acde2867413661ca8ddcc874329983444", null ],
    [ "CoinScoreText", "class_end_level.html#a2a889c8d044016f30c09a7e048c3dbff", null ],
    [ "EndLevelCanvasGroup", "class_end_level.html#a17cfdc1f0c0b98b62647586857f4a550", null ],
    [ "GemAmountText", "class_end_level.html#ad6bc132c99c1f8b77978737b62332952", null ],
    [ "GemScoreText", "class_end_level.html#a778d39f6c117996e9da54cc6d48bb33e", null ],
    [ "LevelScoreText", "class_end_level.html#ad86f4883d727d5908b7fcf097812693b", null ],
    [ "nextLevelButton", "class_end_level.html#a5e254b328cee7e27074c1ad86774e64f", null ],
    [ "TotalScoreText", "class_end_level.html#a45f7ad354c3cdc8420c15318c33a9ff4", null ]
];