var class_game_over_screen =
[
    [ "Exit", "class_game_over_screen.html#aa2f845afa243ee8f137e3ba21766110f", null ],
    [ "Restart", "class_game_over_screen.html#a6b3bd17fb4c6ba979324ef4cd2df5041", null ],
    [ "exitButton", "class_game_over_screen.html#a1dba4c507171dae8d4938529fc51225f", null ],
    [ "restartButton", "class_game_over_screen.html#afcd0c0c11c7fb101777b5962ee2051c4", null ]
];