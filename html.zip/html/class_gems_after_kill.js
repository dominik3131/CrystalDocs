var class_gems_after_kill =
[
    [ "enemyInfo", "class_gems_after_kill.html#a11f692dda8774a8bfed72d4c2d1067b8", null ],
    [ "gemsExists", "class_gems_after_kill.html#a82aad281c16189846d69075c12421415", null ],
    [ "items", "class_gems_after_kill.html#a8b0854bf958602db090b8abca9c6353a", null ]
];