var class_inferno_boss_move =
[
    [ "checkIfDead", "class_inferno_boss_move.html#a3c09876510816a70b977574180ab7992", null ],
    [ "MoveToPosition", "class_inferno_boss_move.html#a5544972b21d0f479386417f3c883598e", null ],
    [ "shootFireballs", "class_inferno_boss_move.html#ae6e09829b137e88014ce17d6ba1a22e5", null ],
    [ "BowInformationCanvas", "class_inferno_boss_move.html#a8f683554d9817969400f6f567267533c", null ],
    [ "bowShooting", "class_inferno_boss_move.html#a5db0918bd5fabefa4bf87ae2db75a63e", null ],
    [ "enemyInteraction", "class_inferno_boss_move.html#a1f9d3d65196c4e395d70050ec5421fca", null ],
    [ "fireball", "class_inferno_boss_move.html#a4a623cf4eb8b90453579d36ea47a66fd", null ],
    [ "fireballSound", "class_inferno_boss_move.html#ababffd89ef31545ef3ee7bbcc6d4f03c", null ],
    [ "firePoint2", "class_inferno_boss_move.html#a35555ec6e172aa6755c3f563d0b688b5", null ],
    [ "isJumping", "class_inferno_boss_move.html#ab514e755fc6f769ce757a352d3df78e6", null ],
    [ "isPlayerShootingDisabled", "class_inferno_boss_move.html#aed7b6baa38f4e17fd6335b49695f3894", null ],
    [ "isResting", "class_inferno_boss_move.html#ab6c6704937f099acda943039bf8b96bd", null ],
    [ "isShooting", "class_inferno_boss_move.html#a224f5f35bd5f3cb6a2e49ebb85145f3d", null ],
    [ "patrol", "class_inferno_boss_move.html#ab415635ac2dfe0675be1967cca312043", null ],
    [ "restSound", "class_inferno_boss_move.html#a6031860d7eb529d7326ad5bbb0d348bb", null ],
    [ "restTime", "class_inferno_boss_move.html#a28a65ee049d96a1370d8f9607d068474", null ]
];