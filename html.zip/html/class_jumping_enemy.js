var class_jumping_enemy =
[
    [ "Awake", "class_jumping_enemy.html#aed767af5b5a7a40b871ceb9207cde7af", null ],
    [ "jumpAction", "class_jumping_enemy.html#ae948c7cdf11835345d19939510a3d3cf", null ],
    [ "Patrol", "class_jumping_enemy.html#a3ab02d71e0b5ab928d1890dc7ed394db", null ],
    [ "Update", "class_jumping_enemy.html#a3696349ee2a37877208e66726b7afdcd", null ],
    [ "nextPlatformInfo", "class_jumping_enemy.html#a54b30c7001b9438309f2fe912beb6a94", null ],
    [ "rigb", "class_jumping_enemy.html#a676234593dc445327440a4467482566c", null ]
];