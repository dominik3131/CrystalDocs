var class_levels_manager =
[
    [ "LevelButtons", "class_levels_manager.html#a30aeca322650c7c70109210e82549422", null ]
];