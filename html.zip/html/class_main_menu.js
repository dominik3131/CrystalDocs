var class_main_menu =
[
    [ "Awake", "class_main_menu.html#a9a2b50b76ed50c4fc1eb08eba7dc23b2", null ],
    [ "Exit", "class_main_menu.html#a2a6f329d1d69aa2ccd1703b061c4d51e", null ],
    [ "NewGame", "class_main_menu.html#a0b9845990e48b948575d2bf6f4dad24d", null ],
    [ "ShowCredits", "class_main_menu.html#aac8172596de17973280ac0fab9d5fcbb", null ],
    [ "ShowMenu", "class_main_menu.html#a09733c45130d7017bae6cee585868c2e", null ],
    [ "ShowSelectLevel", "class_main_menu.html#a71d401f85fc225c8009fb54481681abc", null ],
    [ "creditsButton", "class_main_menu.html#a6739a59291af7abafe91d10b60e57991", null ],
    [ "creditsCanvasGroup", "class_main_menu.html#afcab111b44df61c0fddbbcff00ead2e8", null ],
    [ "CreditsToMenuButton", "class_main_menu.html#a053f285fc2f8361c39831afacb110b62", null ],
    [ "exitButton", "class_main_menu.html#a80bdc6768012dc9f501277f5c9e3853d", null ],
    [ "LevelsToMenuButton", "class_main_menu.html#af462d15204d38c375e8fb7ec4d3b12f6", null ],
    [ "logoCanvasGroup", "class_main_menu.html#a6393fe3aa73fd4cc2c9f7e34212338f4", null ],
    [ "mainMenuCanvasGroup", "class_main_menu.html#a8324bf8090d146e71529f44d37632d70", null ],
    [ "newGameButton", "class_main_menu.html#afe91d9aa109c0b621769451a22004192", null ],
    [ "selectLevelButton", "class_main_menu.html#abced2f6b5f972f1f6bbc315147399a57", null ],
    [ "selectLevelCanvasGroup", "class_main_menu.html#a1af2e3a5d1c29b2a6655490a3f2dce34", null ],
    [ "SettingsToMenuButton", "class_main_menu.html#ac296cdb4cf7780cb55a0c5a5fa9be1f2", null ]
];