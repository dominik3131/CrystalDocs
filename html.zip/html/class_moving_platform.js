var class_moving_platform =
[
    [ "Awake", "class_moving_platform.html#aec6412bf79a5d4fdec57da2e3b390b93", null ],
    [ "Update", "class_moving_platform.html#ad2d623fcb93b97e1070d48c6fd921265", null ],
    [ "currentPoint", "class_moving_platform.html#abac14c14d9bec48416fb91fc1842b133", null ],
    [ "platform", "class_moving_platform.html#a3dde941d4818ecd01a3661656169f211", null ],
    [ "points", "class_moving_platform.html#a7b593f2ccdeb93c5b3fb5cbd98d20be0", null ],
    [ "pointSelection", "class_moving_platform.html#aee8261ea9bb59e022b377e4fe1ee6349", null ],
    [ "speed", "class_moving_platform.html#adf2e0e70bbc8733f8a4e8992ce2447da", null ]
];