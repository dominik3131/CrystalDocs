var class_scrolling =
[
    [ "speed", "class_scrolling.html#aa38faaf288b59e823882e0cc7789110f", null ]
];