var class_spike_controller =
[
    [ "OnCollisionEnter2D", "class_spike_controller.html#a2a4a75d85d699201844f4a6f068377bb", null ],
    [ "damage", "class_spike_controller.html#ab4be3e4f52d0017895a9f139fa9296f1", null ],
    [ "force", "class_spike_controller.html#a1e322804151e7f0160d8ad12534abcb5", null ]
];