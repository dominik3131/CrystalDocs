var class_u_i_controller =
[
    [ "ShowGameOverScreen", "class_u_i_controller.html#ac8960632362bce6ad66da4c32ca1b231", null ],
    [ "UpdateUI", "class_u_i_controller.html#ae6d1c1c945aa8e456a901208baf942cf", null ],
    [ "blocksIcon", "class_u_i_controller.html#a445fd1df144600a3b1dcfd298db754f2", null ],
    [ "blocksText", "class_u_i_controller.html#abfe42d3fa4d774fb88c273f770438ca3", null ],
    [ "coinText", "class_u_i_controller.html#a1a6151f946f1ee657e4bd0f0d4c6cc45", null ],
    [ "GameOverScreenCanvas", "class_u_i_controller.html#a5dca0573da8fdc6de4ebacd1e44048b6", null ],
    [ "gemsText", "class_u_i_controller.html#a063c76fe4259bb93e5d138ac1f465653", null ],
    [ "imgArcher", "class_u_i_controller.html#a584b57dbb9cbbba5094fc28f9f0db42f", null ],
    [ "imgWarrior", "class_u_i_controller.html#a84d03daa9a62a9212d57c3223c000b35", null ],
    [ "imgWizard", "class_u_i_controller.html#af0ee6aa746f89239a2b97836168651dc", null ],
    [ "scoreText", "class_u_i_controller.html#a9eb845eb67cb3403b17de6bd505a4379", null ]
];