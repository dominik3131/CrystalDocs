var class_warrior =
[
    [ "playerInfo", "class_warrior.html#a54ca680c8701d56b80a8e74eaaad54e4", null ],
    [ "warriorAttack", "class_warrior.html#ae23fcc3474c0d47d812194228569394f", null ]
];