var dir_1950c41c008a605fb4b58f26a319ada1 =
[
    [ "AidKit.cs", "_aid_kit_8cs.html", [
      [ "AidKit", "class_aid_kit.html", "class_aid_kit" ]
    ] ],
    [ "Arrow.cs", "_arrow_8cs.html", [
      [ "Arrow", "class_arrow.html", "class_arrow" ]
    ] ],
    [ "Coin.cs", "_coin_8cs.html", [
      [ "Coin", "class_coin.html", "class_coin" ]
    ] ],
    [ "hidingTrap.cs", "hiding_trap_8cs.html", [
      [ "hidingTrap", "classhiding_trap.html", "classhiding_trap" ]
    ] ],
    [ "MovingPlatform.cs", "_moving_platform_8cs.html", [
      [ "MovingPlatform", "class_moving_platform.html", "class_moving_platform" ]
    ] ],
    [ "MovingSaw.cs", "_moving_saw_8cs.html", [
      [ "MovingSaw", "class_moving_saw.html", "class_moving_saw" ]
    ] ],
    [ "Saw.cs", "_saw_8cs.html", [
      [ "Saw", "class_saw.html", "class_saw" ]
    ] ],
    [ "SpikeController.cs", "_spike_controller_8cs.html", [
      [ "SpikeController", "class_spike_controller.html", "class_spike_controller" ]
    ] ]
];