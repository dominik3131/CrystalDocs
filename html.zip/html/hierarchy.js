var hierarchy =
[
    [ "MonoBehaviour", null, [
      [ "AidKit", "class_aid_kit.html", null ],
      [ "Archer", "class_archer.html", null ],
      [ "Arrow", "class_arrow.html", null ],
      [ "Audio", "class_audio.html", null ],
      [ "backgroundMove", "classbackground_move.html", null ],
      [ "BackgroundScroller", "class_background_scroller.html", null ],
      [ "BigFootController", "class_big_foot_controller.html", null ],
      [ "BowShooting", "class_bow_shooting.html", null ],
      [ "CameraFallow", "class_camera_fallow.html", null ],
      [ "CharacterController2D", "class_character_controller2_d.html", null ],
      [ "Coin", "class_coin.html", null ],
      [ "CollsionDetect", "class_collsion_detect.html", null ],
      [ "EndLevel", "class_end_level.html", null ],
      [ "EnemyInteraction", "class_enemy_interaction.html", null ],
      [ "EnemyRangedAttack", "class_enemy_ranged_attack.html", null ],
      [ "EnemyRangedWeapon", "class_enemy_ranged_weapon.html", null ],
      [ "EntMove", "class_ent_move.html", [
        [ "InfernoBossMove", "class_inferno_boss_move.html", null ]
      ] ],
      [ "Fade", "class_fade.html", null ],
      [ "GameOverScreen", "class_game_over_screen.html", null ],
      [ "GemsAfterKill", "class_gems_after_kill.html", null ],
      [ "hidingTrap", "classhiding_trap.html", [
        [ "Saw", "class_saw.html", [
          [ "MovingSaw", "class_moving_saw.html", null ]
        ] ]
      ] ],
      [ "LevelsManager", "class_levels_manager.html", null ],
      [ "MainMenu", "class_main_menu.html", null ],
      [ "MovingPlatform", "class_moving_platform.html", null ],
      [ "PatrolAI", "class_patrol_a_i.html", [
        [ "FollowPatrolAI", "class_follow_patrol_a_i.html", null ],
        [ "JumpingEnemy", "class_jumping_enemy.html", null ]
      ] ],
      [ "PlayerInfo", "class_player_info.html", null ],
      [ "PlayerMovement", "class_player_movement.html", null ],
      [ "RopeScript", "class_rope_script.html", null ],
      [ "SceneLoader", "class_scene_loader.html", null ],
      [ "Scrolling", "class_scrolling.html", null ],
      [ "SimpleEnemyInfo", "class_simple_enemy_info.html", null ],
      [ "SpikeController", "class_spike_controller.html", null ],
      [ "ThrowHook", "class_throw_hook.html", null ],
      [ "ThrowQubic", "class_throw_qubic.html", null ],
      [ "UIController", "class_u_i_controller.html", null ],
      [ "Warrior", "class_warrior.html", null ],
      [ "WarriorAttack", "class_warrior_attack.html", null ],
      [ "Wizard", "class_wizard.html", null ]
    ] ],
    [ "UnityEvent", null, [
      [ "CharacterController2D.BoolEvent", "class_character_controller2_d_1_1_bool_event.html", null ]
    ] ]
];