var searchData=
[
  ['oncollisionenter2d',['OnCollisionEnter2D',['../class_big_foot_controller.html#a96cea6acb53d85d9fdbc6a67a5049e9a',1,'BigFootController.OnCollisionEnter2D()'],['../class_ent_move.html#a5772c57f35eacd080830f01f9d06610c',1,'EntMove.OnCollisionEnter2D()'],['../class_coin.html#ac0f4183b024c7e12b74fa86cfd88facc',1,'Coin.OnCollisionEnter2D()'],['../class_spike_controller.html#a2a4a75d85d699201844f4a6f068377bb',1,'SpikeController.OnCollisionEnter2D()'],['../class_player_info.html#a1f8909a35545765cad8a9be6e1116c14',1,'PlayerInfo.OnCollisionEnter2D()']]],
  ['oncollisionexit2d',['OnCollisionExit2D',['../class_player_info.html#a564d429ee75b914dd7795ddbf25f582b',1,'PlayerInfo']]],
  ['oncrouchevent',['OnCrouchEvent',['../class_character_controller2_d.html#a6b9325f858d5ce6654047a8c7225e4b8',1,'CharacterController2D']]],
  ['oncrouching',['onCrouching',['../class_player_movement.html#a64403f93bb6cfe365955a6e6fda1a1d1',1,'PlayerMovement']]],
  ['onlandevent',['OnLandEvent',['../class_character_controller2_d.html#ac1c8e4c27e899bf1e46f76044c0fbe0a',1,'CharacterController2D']]],
  ['onlanding',['OnLanding',['../class_player_movement.html#abfd7d674aa0d3a70184897dcf7fba738',1,'PlayerMovement']]],
  ['ontriggerenter2d',['OnTriggerEnter2D',['../class_enemy_ranged_weapon.html#ae51632cc3cbcd42d226dc521dd0d3635',1,'EnemyRangedWeapon.OnTriggerEnter2D()'],['../class_arrow.html#ad9f1607469e9da30c32e1fb402b645f7',1,'Arrow.OnTriggerEnter2D()']]],
  ['ouchsounda',['ouchSoundA',['../class_player_info.html#ab5ca879f6428120ee7b254b023306c65',1,'PlayerInfo']]],
  ['ouchsoundb',['ouchSoundB',['../class_player_info.html#a295d8d1ff71f12b0cd96e900bc2447ce',1,'PlayerInfo']]]
];
