var searchData=
[
  ['warrior',['Warrior',['../class_warrior.html',1,'']]],
  ['warriorattack',['WarriorAttack',['../class_warrior_attack.html',1,'']]],
  ['wizard',['Wizard',['../class_wizard.html',1,'']]]
];
