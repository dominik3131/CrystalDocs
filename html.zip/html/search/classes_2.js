var searchData=
[
  ['camerafallow',['CameraFallow',['../class_camera_fallow.html',1,'']]],
  ['charactercontroller2d',['CharacterController2D',['../class_character_controller2_d.html',1,'']]],
  ['coin',['Coin',['../class_coin.html',1,'']]],
  ['collsiondetect',['CollsionDetect',['../class_collsion_detect.html',1,'']]]
];
