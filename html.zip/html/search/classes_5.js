var searchData=
[
  ['gameoverscreen',['GameOverScreen',['../class_game_over_screen.html',1,'']]],
  ['gemsafterkill',['GemsAfterKill',['../class_gems_after_kill.html',1,'']]]
];
