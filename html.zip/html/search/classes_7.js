var searchData=
[
  ['infernobossmove',['InfernoBossMove',['../class_inferno_boss_move.html',1,'']]]
];
