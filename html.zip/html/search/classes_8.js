var searchData=
[
  ['jumpingenemy',['JumpingEnemy',['../class_jumping_enemy.html',1,'']]]
];
