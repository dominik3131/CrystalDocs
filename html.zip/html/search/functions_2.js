var searchData=
[
  ['defend',['defend',['../class_big_foot_controller.html#acf29cdd46ef2e4316d74cbed48a68301',1,'BigFootController.defend()'],['../class_ent_move.html#a4873df1e79ac48b3c45d1be4c24c90f2',1,'EntMove.defend()']]]
];
