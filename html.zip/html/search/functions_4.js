var searchData=
[
  ['fadecanvas',['FadeCanvas',['../class_fade.html#af14d6e88e20cb9a7a414174b16922c15',1,'Fade']]],
  ['fixedupdate',['FixedUpdate',['../class_camera_fallow.html#a395318473aac63b39553404c1aca710c',1,'CameraFallow.FixedUpdate()'],['../class_player_movement.html#a0caaa871b9ef680c9f02bd0e22c77db1',1,'PlayerMovement.FixedUpdate()']]]
];
