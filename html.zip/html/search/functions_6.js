var searchData=
[
  ['jumpaction',['jumpAction',['../class_big_foot_controller.html#ad09a26b8d84ef0b437eb67d6016ed46f',1,'BigFootController.jumpAction()'],['../class_ent_move.html#a0b344d053060c1bcae639075de1fbb87',1,'EntMove.jumpAction()'],['../class_jumping_enemy.html#ae948c7cdf11835345d19939510a3d3cf',1,'JumpingEnemy.jumpAction()']]]
];
