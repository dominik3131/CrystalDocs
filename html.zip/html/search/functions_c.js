var searchData=
[
  ['rangeattack',['rangeAttack',['../class_big_foot_controller.html#a8dc1cc9100ea29a0cd9ee2c0edbcb23d',1,'BigFootController.rangeAttack()'],['../class_ent_move.html#a0b1bdc1c8dcdce4f72204ed9bf5d306f',1,'EntMove.rangeAttack()']]],
  ['refreshhealthbar',['RefreshHealthBar',['../class_player_info.html#a344047fec8c271c149cd282a265135ac',1,'PlayerInfo']]],
  ['resetnodesdistance',['resetNodesDistance',['../class_rope_script.html#af5870a2757917b945f2e73e2f5c97334',1,'RopeScript']]],
  ['restart',['Restart',['../class_game_over_screen.html#a6b3bd17fb4c6ba979324ef4cd2df5041',1,'GameOverScreen']]],
  ['rotate',['Rotate',['../class_patrol_a_i.html#a84f04af4c217084ebe06023791a5dd7f',1,'PatrolAI']]]
];
