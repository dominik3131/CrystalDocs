var searchData=
[
  ['takedamage',['TakeDamage',['../class_simple_enemy_info.html#af0c7ddd2583d9586268a0fd6be0f43e0',1,'SimpleEnemyInfo.TakeDamage()'],['../class_player_info.html#aa3e8d1d61329d7a237db1ec9fb263a46',1,'PlayerInfo.TakeDamage()']]]
];
