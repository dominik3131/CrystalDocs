var searchData=
[
  ['jump',['jump',['../class_player_movement.html#af33cc9d4c2dc2e8a0ce69b42764b2f27',1,'PlayerMovement']]],
  ['jumpattackdomage',['jumpAttackDomage',['../class_big_foot_controller.html#adea3ae16c46c127c905005a5e2f4c6ac',1,'BigFootController.jumpAttackDomage()'],['../class_ent_move.html#a527ef4ea868a6874a2c2a7f233b51cbd',1,'EntMove.jumpAttackDomage()']]]
];
