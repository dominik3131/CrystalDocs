var searchData=
[
  ['newgamebutton',['newGameButton',['../class_main_menu.html#afe91d9aa109c0b621769451a22004192',1,'MainMenu']]],
  ['nextlevelbutton',['nextLevelButton',['../class_end_level.html#a5e254b328cee7e27074c1ad86774e64f',1,'EndLevel']]],
  ['nextplatforminfo',['nextPlatformInfo',['../class_jumping_enemy.html#a54b30c7001b9438309f2fe912beb6a94',1,'JumpingEnemy']]],
  ['nodeprefab',['nodePrefab',['../class_rope_script.html#a662a999ed14095d9eb170988a5c4fd3a',1,'RopeScript']]],
  ['numberofprojectiles',['numberOfProjectiles',['../class_big_foot_controller.html#aaeeebc1ba2ae327113de17f1d4ca27ef',1,'BigFootController.numberOfProjectiles()'],['../class_ent_move.html#a275a6f21d62d971cad3ac4e3bb767d73',1,'EntMove.numberOfProjectiles()']]],
  ['numberofterrainlayer',['numberOfTerrainLayer',['../class_throw_hook.html#af9d1470b671bdd2a3ad1662a6293b620',1,'ThrowHook']]]
];
