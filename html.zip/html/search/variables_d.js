var searchData=
[
  ['oncrouchevent',['OnCrouchEvent',['../class_character_controller2_d.html#a6b9325f858d5ce6654047a8c7225e4b8',1,'CharacterController2D']]],
  ['onlandevent',['OnLandEvent',['../class_character_controller2_d.html#ac1c8e4c27e899bf1e46f76044c0fbe0a',1,'CharacterController2D']]],
  ['ouchsounda',['ouchSoundA',['../class_player_info.html#ab5ca879f6428120ee7b254b023306c65',1,'PlayerInfo']]],
  ['ouchsoundb',['ouchSoundB',['../class_player_info.html#a295d8d1ff71f12b0cd96e900bc2447ce',1,'PlayerInfo']]]
];
